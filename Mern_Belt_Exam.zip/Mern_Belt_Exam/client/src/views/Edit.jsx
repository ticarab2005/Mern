import React, { useState, useEffect } from "react";
import axios from 'axios';
import { useHistory, Link, useParams } from "react-router-dom";

const Edit = (props) => {
    const {_id} = useParams();
    const [form, setForm] = useState({
        name: "",
        type: "",
        description: "",
        skillOne:"",
        skillTwo:"",
        skillThree:""
    })

    const [errors, setErrors] = useState({});
    const history = useHistory();

    useEffect(() => {
        console.log(_id)
        axios.get(`http://localhost:8000/api/pets/${_id}`)
            .then(res => {
                console.log(res.data.results);
                setForm(res.data.results);
            })
            .catch(err => console.log(err))
    }, [_id])

    const onChangeHandler = (event) => {
        setForm({
            ...form,
            [event.target.name]: event.target.value
        })
    }

    const onSubmitHandler = (event) => {
        event.preventDefault();
        axios.patch(`http://localhost:8000/api/pets/${_id}/update`, form)
            .then(res => {
                console.log(res);
                history.push("/")
            })
            .catch(err => {
                console.log(err.response.data.err.errors);
                setErrors(err.response.data.err.errors);
            })
    }

    return (
        <div>
            <div className="d-flex justify-content-between mx-5 mb-2">
                <h1>Pet Shelter</h1>
                <Link to={"/"}>back to home</Link>
            </div>
                <h4 className="mb-3">Edit {form.name}</h4>
            <div className="w-50 mx-auto box">
                <form onSubmit={onSubmitHandler}>
                    <div className="row g-2 d-flex bd-highlight">
                        <div className="col-md p-2 w-100 bd-highlight">
                            <div className="form-group">
                                <label htmlFor="name">Pet Name:</label>
                                <input type="text" className="form-control" value={form.name} name="name" onChange={onChangeHandler} />
                                <span className="alert-danger">{errors.name && errors.name.message}</span>
                            </div>
                            <div className="form-group">
                                <label htmlFor="type">Pet Type:</label>
                                <input type="text" className="form-control" value={form.type} name="type" onChange={onChangeHandler} />
                                <span className="alert-danger">{errors.type && errors.type.message}</span>
                            </div>
                            <div className="form-group">
                                <label htmlFor="description">Pet Description:</label>
                                <input type="text" className="form-control" value={form.description} name="description" onChange={onChangeHandler} />
                                <span className="alert-danger">{errors.description && errors.description.message}</span>
                            </div>
                            <br />
                            <input type="submit" value="🖊 Edit Pet" className="btn btn-primary" />
                        </div>
                        <div className="col-md p-2 w-100 bd-highlight">
                            <p>Skills (optional):</p>
                            <div className="form-group">
                                <label htmlFor="skillOne">Skill 1:</label>
                                <input type="text" className="form-control" value={form.skillOne} name="skillOne" onChange={onChangeHandler} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="skillTwo">Skill 2:</label>
                                <input type="text" className="form-control" value={form.skillTwo} name="skillTwo" onChange={onChangeHandler} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="skillThree">Skill 3:</label>
                                <input type="text" className="form-control" value={form.skillThree} name="skillThree" onChange={onChangeHandler} />
                            </div>
                
                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default Edit;