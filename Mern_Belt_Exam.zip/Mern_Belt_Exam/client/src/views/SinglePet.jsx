import React, { useEffect, useState } from "react";
import { useParams, Link, useHistory } from "react-router-dom";
import axios from "axios";

const SinglePet = (props) => {
    const { _id } = useParams();
    const [results, setResults] = useState([]);
    const history = useHistory();

    useEffect(() => {
        axios.get("http://localhost:8000/api/pets/" + _id)
            .then(res => {
                console.log(res.data.results);
                setResults(res.data.results)
            })
            .catch(err => console.log(err))
    }, [_id])

    const onDeleteHandler = (_id, index) => {
        console.log(_id)
        console.log(index)
        axios.delete(`http://localhost:8000/api/pets/${_id}/delete`)
            .then(res => {
                console.log(res);
                history.push("/")
            })
            .catch(err => {
                console.log(err)
                setResults("")
            })
    }

    return (
        <div>
            <div className="d-flex justify-content-between mx-5 mb-2">
                <h1>Pet Shelter</h1>
                <Link to={"/"}>back to home</Link>
            </div>
            <div className="d-flex justify-content-between mx-5 mb-">
                <h5>Details about {results.name}</h5>
                <button onClick={() => onDeleteHandler(results._id)} className="btn btn-sm btn-danger">🏠 Adopt {results.name}</button>
            </div>
            <div className="box">
                <p><b>Pet type: </b>{results.type}</p>
                <p><b>Description: </b>{results.description}</p>
                <div className="d-flex">
                    <p className="me-2"><b>Skills:</b></p>
                    <ul>
                        <li>{results.skillOne}</li>
                        <li>{results.skillTwo}</li>
                        <li>{results.skillThree}</li>
                    </ul>
                </div>

            </div>
        </div>
    )
}

export default SinglePet;