import React, { useState } from "react";
import axios from 'axios';
import { useHistory, Link } from "react-router-dom";

const Create = (props) => {
    const [form, setForm] = useState({
        name: "",
        type: "",
        description: "",
        skillOne: "",
        skillTwo: "",
        skillThree: ""
    })

    const [errors, setErrors] = useState({});
    const history = useHistory();

    const onChangeHandler = (event) => {
        setForm({
            ...form,
            [event.target.name]: event.target.value
        })
    }

    const onSubmitHandler = (event) => {
        event.preventDefault();

        axios.post("http://localhost:8000/api/pets/create", form)
            .then(res => {
                console.log(res);
                history.push(`/`);
            })
            .catch(err => {
                console.log(err.response.data.err.errors);
                setErrors(err.response.data.err.errors);
            })
    }

    return (
        <div>
            <div className="d-flex justify-content-between mx-5 mb-2">
                <h1>Pet Shelter</h1>
                <Link to={"/"}>back to home</Link>
            </div>
            <h4 className="mb-3 mx-5 text-start">Know a pet needing a home?</h4>
            <div className="w-50 box">
                <form onSubmit={onSubmitHandler}>
                    <div className="row g-2 d-flex bd-highlight">
                        <div className="col-md p-2 w-100 bd-highlight">
                            <div className="form-group">
                                <label htmlFor="name">Pet Name:</label>
                                <input type="text" className="form-control" name="name" onChange={onChangeHandler} />
                                <span className="alert-danger">{errors.name && errors.name.message}</span>
                            </div>
                            <div className="form-group">
                                <label htmlFor="type">Pet Type:</label>
                                <input type="text" className="form-control" name="type" onChange={onChangeHandler} />
                                <span className="alert-danger">{errors.type && errors.type.message}</span>
                            </div>
                            <div className="form-group">
                                <label htmlFor="description">Pet Description:</label>
                                <input type="text" className="form-control" name="description" onChange={onChangeHandler} />
                                <span className="alert-danger">{errors.description && errors.description.message}</span>
                            </div>
                            <br />
                            <input type="submit" value="🔼 Add Pet" className="btn btn-primary" />
                        </div>
                        <div className="col-md p-2 w-100 bd-highlight">
                            <p>Skills (optional):</p>
                            <div className="form-group">
                                <label htmlFor="skillOne">Skill 1:</label>
                                <input type="text" className="form-control" name="skillOne" onChange={onChangeHandler} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="skillTwo">Skill 2:</label>
                                <input type="text" className="form-control" name="skillTwo" onChange={onChangeHandler} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="skillThree">Skill 3:</label>
                                <input type="text" className="form-control" name="skillThree" onChange={onChangeHandler} />
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default Create;