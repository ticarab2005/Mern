import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import Dashboard from "../components/Dashboard";

const Detail = (props) => {
    const [pets, setPets] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pets/findAll`)
            .then(res => {
                console.log(res);
                setPets(res.data.results)
            })
            .catch(err => console.log(err))
    }, [])

    return (
        <div>
            <div className="d-flex justify-content-between mx-5">
                <h1>Pet Shelter</h1>
                <Link to={"/pets/create"}>add a pet to the shelter</Link>
            </div>
            <h3>These pets are looking for a good home</h3>
            <table className="table table-bordered">
                <thead>
                    <tr>
                        <th className="col">Name</th>
                        <th className="col">Type</th>
                        <th className="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        pets.map((pet, i) => {
                            return <Dashboard key={i} pet={pet} />
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default Detail;