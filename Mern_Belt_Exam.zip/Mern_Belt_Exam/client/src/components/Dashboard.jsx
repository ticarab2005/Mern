import React from "react";
import { Link } from 'react-router-dom'

const Dashboard = (props) => {
    return (

            <tr>
                <td scope="row">{props.pet.name}</td>
                <td>{props.pet.type}</td>
                <td>
                    <Link to={`/pets/${props.pet._id}`}>details</Link>
                    <Link to={`/pets/${props.pet._id}/edit`} className="fs-8 mx-2">edit</Link>
                </td>
            </tr>

    )
}

export default Dashboard;