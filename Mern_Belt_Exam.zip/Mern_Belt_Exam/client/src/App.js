import 'bootstrap/dist/css/bootstrap.min.css'
import React from 'react';
import './App.css';
import { Switch, Route } from 'react-router-dom'
import Detail from './views/Detail';
import Create from './views/Create';
import SinglePet from './views/SinglePet';
import Edit from './views/Edit';

function App() {
  return (
    <div className="App">
      <Switch>
        <Route exact path="/pets/create">
          <Create/>
        </Route>
        <Route exact path="/pets/:_id">
          <SinglePet/>
        </Route>
        <Route exact path="/">
          <Detail/>
        </Route>
        <Route exact path="/pets/:_id/edit">
          <Edit/>
        </Route>
      </Switch>
    </div>
  );
}

export default App;
