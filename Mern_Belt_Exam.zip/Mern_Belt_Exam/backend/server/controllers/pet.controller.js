const Pet = require("../models/pet.model");

module.exports.petResponse = (req,res) => {
    res.json({message:"hey hey, everything's running!"})
}

module.exports.findAll = (req, res) => {
    Pet.find({}).sort([['type',-1]])
        .then(results => res.json({ results: results }))
        .catch(err => res.status(400).json({ message: "ahh ahhhh ahhhh, you didn't say the magic words!", err }))
}

module.exports.createPet = (req, res) => {
    Pet.create(req.body)
        .then(newPet => res.json({ results: newPet }))
        .catch(err => res.status(400).json({ message: "ahh ahhhh ahhhh, you didn't say the magic words!", err }))
}

module.exports.findOnePet = (req, res) => {
    Pet.findOne({ _id: req.params._id })
        .then(results => res.json({ results: results }))
        .catch(err => res.status(400).json({ message: "ahh ahhhh ahhhh, you didn't say the magic words!", err }))
}

module.exports.deletePet = (req,res) =>{
    Pet.deleteOne({_id:req.params._id})
    .then(results => res.json({ results: results }))
    .catch(err => res.status(400).json({ message: "ahh ahhhh ahhhh, you didn't say the magic words!", err }))
}

module.exports.updateOnePet = (req,res) => {
    Pet.updateOne({_id:req.params._id},req.body,{runValidators:true})
    .then(updateOnePet => res.json({ results: updateOnePet }))
    .catch(err => res.status(400).json({ message: "ahh ahhhh ahhhh, you didn't say the magic words!", err }))
}
