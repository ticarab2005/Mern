const PetController = require("../controllers/pet.controller");

module.exports = app =>{
    app.get("/api/pet", PetController.petResponse);
    app.get("/api/pets/findAll", PetController.findAll);
    app.post("/api/pets/create",PetController.createPet);
    app.get("/api/pets/:_id",PetController.findOnePet);
    app.delete("/api/pets/:_id/delete",PetController.deletePet);
    app.patch("/api/pets/:_id/update",PetController.updateOnePet);
}